/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
import grafo.v;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**
 *
 * @author DiBot
 */
public class vbase implements v{
    int id;
    int valor;

    vbase(int id){
        this.id = id;
    }

    public void setValue(int valor) {
        this.valor = valor;
    }
    @Override
    public String getId() {
        return id+"";
    }

    @Override
    public String getLabel() {
        return "Node-"+id+" ("+valor+")";
    }

    @Override
    public Integer getValue() {
        return valor;
    }
}
