/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
import grafo.lado;
import grafo.G;
import grafo.v;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;
/**
 *
 * @author DiBot
 */
public class manejo {
    
    public static void guardaG(String nombre,G graph, int dir)
    {   
        if (dir==1){
        try {
            BufferedWriter escritura = new BufferedWriter(new FileWriter(nombre));
            escritura.write(graph.formatografoDI("a"));
            escritura.close();
        }
        catch (Exception no)
        {
            System.out.print("no se creo el achivo");

        }

    }

   
       if (dir==0){
        try {
            BufferedWriter escritura = new BufferedWriter(new FileWriter(nombre));
            escritura.write(graph.formatografo("a"));
            escritura.close();
        }
        catch (Exception no)
        {
             System.out.print("no se creo el achivo");
         
        }

    }
 }
    
}
