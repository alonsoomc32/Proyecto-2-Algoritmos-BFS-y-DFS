/*
 * To change this license cabeza, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
package grafo;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;

/**
 *
 * @author DiBot
 */
public class degv <New extends v> extends Funciones1<New>{
   
}
