/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
import grafo.v;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**
 *
 * @author DiBot
 */
public class Teorias2 implements v{
    int id, valor;
    double x,y;
   
    
      Teorias2(int id,double x, double y){
        this.id = id;
        this.x = x;
        this.y = y;
    }

    @Override
    public String getId() {
        return id+"";
    }

    @Override
    public String getLabel() {
        return "Node-"+id+" ("+valor+")";
    }

    @Override
    public Integer getValue() {
        return valor;
    }

    @Override
    public void setValue(int valor) {
        this.valor = valor;
    }
}
