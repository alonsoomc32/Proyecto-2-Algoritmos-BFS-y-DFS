/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
package grafo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Stack;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**
 *
 * @author DiBot
 */

public class G<New extends v> extends Funciones1<New> {
                     //Metodos de busqueda
      public G BFS(v start)
    {
        G arbol = new G();
        
        LinkedList<v> nodos = new LinkedList<>();
        HashSet<v> vconocidos = new HashSet<>();

        nodos.add(start);
        vconocidos.add(start);
        arbol.addv(start);

        while (!nodos.isEmpty())
        {
            v nodoI = nodos.poll();

            for (lado Lados : getEdgesOfNode(getIndex(nodoI)))
            {
                v vecinos;
                if (Lados.tomarNodo2() == nodoI)
                {
                    vecinos = Lados.tomarNodo1();
                }
                else
                {
                    vecinos = Lados.tomarNodo2();
                }
                if (!vconocidos.contains(vecinos))
                {
                    vconocidos.add(vecinos);
                    nodos.add(vecinos);
                    arbol.addv(vecinos);
                    arbol.addlado(arbol.getIndex(nodoI),arbol.getIndex(vecinos));
                   
                    ;
                }
            }
        }

        return arbol;
    }
       public G DFS(v s)
    {
        HashSet<v> descubierto = new HashSet<>();
        G arbol = new G();

        arbol.addv(s);
        DFSR(s,descubierto,arbol);

        return arbol;
    }

    public void DFSR (v s,HashSet<v> descubierto,G arbol)
    {
        descubierto.add(s);
        for (lado e : getEdgesOfNode(getIndex(s)))
        {
            v vecinos;
            if (e.tomarNodo1() == s)
            {
                vecinos = e.tomarNodo2();
            }
            else
            {
                vecinos = e.tomarNodo1();
            }

            if (!descubierto.contains(vecinos))
            {
                arbol.addv(vecinos);
                arbol.addlado(arbol.getIndex(e.tomarNodo1()),arbol.getIndex(e.tomarNodo2()));
                DFSR(vecinos,descubierto,arbol);
            }
        }
    }
    
   public G DFSI(v s)
    {
        HashSet<v> descubierto = new HashSet<>();
        G arbol = new G();
        Stack<v> pila = new Stack<>();

        pila.push(s);
        arbol.addv(s);

        v prev = null;

        while (!pila.isEmpty())
        {
            v v = pila.pop();

            if (!descubierto.contains(v))
            {
                if (prev != null)
                {
                    arbol.addv(v);
                    arbol.addlado(arbol.getIndex(prev), arbol.getIndex(v));
                }
                else {
                    arbol.addv(prev);
                }

                descubierto.add(v);
                ArrayList<lado<New>> vecinoss = getEdgesOfNode(getIndex(v));
                
                for (lado edge : vecinoss)
                {
                    v vecinos;
                    if (edge.tomarNodo1() == v)
                    {
                        vecinos = edge.tomarNodo2();
                    }
                    else {
                        vecinos = edge.tomarNodo1();
                    }

                    if (!descubierto.contains(vecinos))
                    {
                        pila.push(vecinos);
                    }
                }
                prev = v;
            }
        }

        return arbol;
    }
    
}



