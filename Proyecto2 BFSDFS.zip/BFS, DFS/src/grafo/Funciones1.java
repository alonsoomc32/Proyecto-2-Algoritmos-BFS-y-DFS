/*
 * To change this license cabeza, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
package grafo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Stack;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**
 *
 * @author DiBot
 */

abstract class Funciones1<New extends v> {
    protected ArrayList<New> nodos;
    protected ArrayList<lado<New>> lados;

    Funciones1()
    {
        this.nodos = new ArrayList<>();
        this.lados = new ArrayList<>();
    }

    public New getv(int index)
    {
        New node = null;
        if (validateIndex(index,nodos))
        {
            node = nodos.get(index) ;
        }

        return node;
    }

    public void addv(New node){
        if (node != null) {
            this.nodos.add(node);
        }
    }
    
     public lado<New> getEdge(int index)
    {
        if (validateIndex(index,lados)) {
            return new lado(lados.get(index));
        }

        return null;
    }
    public int getladoIndex(lado edge)
    {
        return lados.indexOf(edge);
    }

      public int getIndex(v node)
    {
        return nodos.indexOf(node);
    }
      
       public ArrayList<lado<New>> getEdgesOfNode(int index){
        ArrayList<lado<New>> nodeEdges = null;

        if (validateIndex(index,nodos)) {
            v node = nodos.get(index);

            if (node != null) {
                nodeEdges = new ArrayList<>();

                for (lado edge : lados) {
                    if (node == edge.tomarNodo1() || node == edge.tomarNodo2()) {
                        nodeEdges.add(edge);
                    }
                }
            }
        }

        return  nodeEdges;
    }  
      
      

    public void addlado(int index1, int index2){
        if (validateIndex(index1,nodos) && validateIndex(index2, nodos)) {

            v node1 = nodos.get(index1);
            v node2 = nodos.get(index2);
            System.out.println("Grafo  autodirigido");
            if (node1 != null && node2 != null) {
                lado edge = new lado(node1, node2);

                if (!tienelado(edge))
                {
                    lados.add(edge);
                }
            }
        }
    }
    public void addladonod(int index1, int index2){
        if (validateIndex(index1,nodos) && validateIndex(index2, nodos)) {

            v node1 = nodos.get(index1);
            v node2 = nodos.get(index2);
            System.out.print("Grafo no autodirigido");
            if (node1 != null && node2 != null) {
                
                lado edge = new lado(node1, node2);
                    lados.add(edge);
                
            }
        }
    }
    
    public boolean tienelado(lado edge)
    {
        for (lado edge1:lados)
        {
            if (edge == edge1)
            {
                return true;
            }
        }

        return false;
    }

    public int gradov(int index)
    {
        int grado = 0;

        if (validateIndex(index,nodos))
        {
            v node = nodos.get(index);
            if (node != null)
            {
                for (lado edge:lados)
                {
                    if (node == edge.tomarNodo1())
                    {
                        grado++;
                    }
                    if (node == edge.tomarNodo2())
                    {
                        grado++;
                    }
                }
            }
        }

        return grado;
    }

    protected boolean validateIndex(int index, ArrayList list)
    {
        return list != null && index >=0 && index < list.size();
    }

    public String formatoG(){
        String primernodo = "nodedef> name VARCHAR,label VARCHAR\n";
        String primerlado = "edgedef> node1,node2\n";

        String grafo = primernodo;

        for (v node:nodos)
        {
            grafo += node.getId()+","+node.getLabel()+"\n";
        }


        grafo += primerlado;
        for (lado edge:lados){
            grafo += edge.tomarNodo1().getId()+","+edge.tomarNodo2().getId()+"\n";
        }

        return grafo;
    }

    public String formatografo(String name){
        String cabeza = "graph "+name+" { \n";

        String grafo = cabeza;

        for (lado edge:lados){
            grafo += edge.tomarNodo1().getId()+"--"+edge.tomarNodo2().getId()+";\n";
        }

        for (v n:nodos)
        {
            if (!n.getLabel().isEmpty())
                grafo += n.getId()+" "+"[label=\""+n.getLabel()+"\"]"+";\n";
        }

        grafo += "}";

        return grafo;
    }
    
     public String formatografoDI(String name){
        String cabeza = "digraph "+name+" { \n";

        String grafo = cabeza;

        for (lado edge:lados){
            grafo += edge.tomarNodo1().getId()+"->"+edge.tomarNodo2().getId()+";\n";
        }

        for (v n:nodos)
        {
            if (!n.getLabel().isEmpty())
                grafo += n.getId()+" "+"[label=\""+n.getLabel()+"\"]"+";\n";
        }

        grafo += "}";

        return grafo;
    }
}
