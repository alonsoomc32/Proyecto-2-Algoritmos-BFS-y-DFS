/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
package grafo;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;

/**
 *
 * @author DiBot
 */

public interface v{

    String getId();
    String getLabel();
    Integer getValue();
    void setValue(int valor);
}
