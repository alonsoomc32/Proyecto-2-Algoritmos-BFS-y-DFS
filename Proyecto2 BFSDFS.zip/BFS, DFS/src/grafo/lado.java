/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
package grafo;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**}
 *
 * @author DiBot
 */

public class lado<New extends v> {
    private New n1;
    private New n2;
    
     lado(lado<New> lado)
    {
        this.n1 = lado.n1;
        this.n2 = lado.n2;
    }
     
    lado(New n1, New n2)
    {
        this.n1 = n1;
        this.n2 = n2;
    }

    void darNodo1(New n1) {
        this.n1 = n1;
    }

    void darNodo2(New n2) {
        this.n2 = n2;
    }

    public final New tomarNodo1() {
        return n1;
    }

    public final New tomarNodo2() {
        return n2;}



}