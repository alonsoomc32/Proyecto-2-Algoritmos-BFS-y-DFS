/*
 * To change this license cabeza, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
import grafo.lado;
import grafo.G;
import grafo.v;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;
import java.lang.*; 

/**
 *
 * @author DiBot
 */
public class teorias {
    public static G<vbase> Erdos(int n,int m, int dir, int auto)
    {
         if (m==0||m<1 ||n==0||n<1){
            System.out.print("Dame un valor correcto");
             System.exit(0);
        }
        G<vbase> nuevografo = new G<>();

        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
        }

        Random random = new Random();
        for (int i=0; i < m ; i++)
        {
            int n1 = random.nextInt(n);
            int n2 = random.nextInt(n);
            System.out.print(n1+" --> ");
             System.out.print(n2);
              System.out.println("");
            
           if ((auto==1) && (dir==1)){
               
               nuevografo.addlado(n1, n2);
           }
           else if ((auto==1) && (dir==0)){
               nuevografo.addlado(n1, n2);
           }
           else if ((auto==0) && (dir==1)&& n1 !=n2){
               nuevografo.addladonod(n1, n2);
           }
               
           else if (auto==0 && dir==0 && n1 !=n2) {
               //(n1 != n2) 
               nuevografo.addladonod(n1, n2);
               
            } 
        }

        return nuevografo;
    }

    public static G<vbase> Gilbert(int n,double p,int dir, int auto)
    {
        if (p==0||n==0||n<1){
            System.out.print("Dame un valor correcto");
             System.exit(0);
        } 
        G<vbase> nuevografo = new G<>();
         
         if ((auto==1) && (dir==1)){
           System.out.println("Grafo  dirigido");
           System.out.println("Grafo  aciclico");

        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
        }
         Random random = new Random();
         for (int i=0; i < n && i<499 ; i++)
        {
            for (int j=0; j < n && j<499; j++)
            {
                if ( random.nextDouble() < p)
                {
                    System.out.print(i+" --> ");
                    System.out.print(j);
                    System.out.println("");
                    nuevografo.addlado(i,j);
                }
            }

        }

    }
        /* else if ((auto==1) && (dir==0)){
             
         }
         else if ((auto==0) && (dir==1)){
             
         }*/
         else if ((auto==1) && (dir==0)){
           System.out.println("Grafo NO dirigido");
           System.out.println("Grafo  aciclico");
                for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
        }
         Random random = new Random();
         for (int i=0; i < n && i<499 ; i++)
        {
            for (int j=0; j < n && j<499; j++)
            {
                if ( random.nextDouble() < p)
                {
                    System.out.print(i+" --> ");
                    System.out.print(j);
                    System.out.println("");
                    nuevografo.addlado(i,j);
                }
            }

        }
         }
         else if ((auto==0) && (dir==1)){
                System.out.println("Grafo  Dirigido");
                System.out.println("Grafo NO aciclico");

        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
        }
         Random random = new Random();
         for (int i=0; i < n ; i++)
        {
            for (int j=0; j < n; j++)
            {
                if ( i != j && random.nextDouble() < p)
                {
                    System.out.print(i+" --> ");
                    System.out.print(j);
                    System.out.println("");
                    nuevografo.addlado(i,j);
                }
            }

        }
         }
         else if ((auto==0) && (dir==0)){
               System.out.println("Grafo  NO autodirigido");
                System.out.println("Grafo NO aciclico");

        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
        }
         Random random = new Random();
         for (int i=0; i < n ; i++)
        {
            for (int j=0; j < n; j++)
            {
                if ( i != j && random.nextDouble() < p)
                {
                    System.out.print(i+" --> ");
                    System.out.print(j);
                    System.out.println("");
                    nuevografo.addlado(i,j);
                }
            }

        }

        
    }
          
        
          return nuevografo;  
    }

    public static G<Teorias2> Geografico(int n, double r,int dir, int auto)
    {
        if (r==0 ||n==0||n<1 ){
            System.out.print("Dame un valor correcto");
             System.exit(0);
        }
        G<Teorias2> nuevografo= new G<>();

        if ((auto==1) && (dir==1)){
           System.out.println("Grafo  autodirigido");
           
        Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new Teorias2(i,random.nextDouble(),random.nextDouble()));
        }

        for (int i=0; i < n ; i++)
        {
            Teorias2 node1 = nuevografo.getv(i);

            for (int j=0; j < n; j++) {
                Teorias2 node2 = nuevografo.getv(j);
                double c = Math.sqrt(Math.pow(Math.abs(node1.x-node2.x),2)+Math.pow(Math.abs(node1.y-node2.y),2));

             
               if (c <= r) 
               {
                    nuevografo.addlado(i,j);
                }
            }
        }
         }
        else if ((auto==1) && (dir==0)){
             System.out.println("Grafo Aciclico");
             System.out.println("Grafo No Dirigido");
               
        Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new Teorias2(i,random.nextDouble(),random.nextDouble()));
        }

        for (int i=0; i < n ; i++)
        {
            Teorias2 node1 = nuevografo.getv(i);

            for (int j=0; j < n; j++) {
                Teorias2 node2 = nuevografo.getv(j);
                double c = Math.sqrt(Math.pow(Math.abs(node1.x-node2.x),2)+Math.pow(Math.abs(node1.y-node2.y),2));

             
               if (c <= r) 
               {
                    nuevografo.addlado(i,j);
                }
            }
        }  
               
         }
         else if ((auto==0) && (dir==1)){
              System.out.println("Grafo NO aciclico");
               System.out.println("Grafo Dirigido");
               Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new Teorias2(i,random.nextDouble(),random.nextDouble()));
        }

        for (int i=0; i < n ; i++)
        {
            Teorias2 node1 = nuevografo.getv(i);

            for (int j=0; j < n; j++) {
                Teorias2 node2 = nuevografo.getv(j);
                double c = Math.sqrt(Math.pow(Math.abs(node1.x-node2.x),2)+Math.pow(Math.abs(node1.y-node2.y),2));

                if (i != j && c <= r)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
               
         }
         
        else if ((auto==0) && (dir==0)){
           System.out.println("Grafo NO autodirigido");
            Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new Teorias2(i,random.nextDouble(),random.nextDouble()));
        }

        for (int i=0; i < n ; i++)
        {
            Teorias2 node1 = nuevografo.getv(i);

            for (int j=0; j < n; j++) {
                Teorias2 node2 = nuevografo.getv(j);
                double c = Math.sqrt(Math.pow(Math.abs(node1.x-node2.x),2)+Math.pow(Math.abs(node1.y-node2.y),2));

                if (i != j && c <= r)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
         }
           
 
        return nuevografo;
    }

    public static G<vbase> Barabasi(int n,double d, int dir, int auto)
    {
        if (d==0||d<1 ||n==0||n<1 ){
            System.out.print("Dame un valor correcto");
             System.exit(0);
        }
            
        G<vbase> nuevografo = new G<>();
        if ((auto==1) && (dir==1)){
        System.out.println("Grafo autociclico");
        System.out.println("Grafo Dirigido");
        Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
            for (int j=0;j < n;j++)
            {
                double p = 1-nuevografo.gradov(j)/d;
                if ( random.nextDouble() <= p)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
    }
        else if ((auto==1) && (dir==0)){
        System.out.println("Grafo autociclico");
        System.out.println("Grafo NO Dirigido");
        Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
            for (int j=0;j < n;j++)
            {
                double p = 1-nuevografo.gradov(j)/d;
                if ( random.nextDouble() <= p)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
         }
         else if ((auto==0) && (dir==1)){
        System.out.println("Grafo nO autociclico");
        System.out.println("Grafo Dirigido");     
        
           Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
            for (int j=0;j < n;j++)
            {
                double p = 1-nuevografo.gradov(j)/d;
                if (i != j && random.nextDouble() <= p)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
         
         }
        else if ((auto==0) && (dir==0)){
           System.out.println("Grafo NO autodirigido");
           Random random = new Random();
        for (int i=0;i < n;i++)
        {
            nuevografo.addv(new vbase(i));
            for (int j=0;j < n;j++)
            {
                double p = 1-nuevografo.gradov(j)/d;
                if (i != j && random.nextDouble() <= p)
                {
                    nuevografo.addlado(i,j);
                }
            }
        }
           
    }
        return nuevografo;
    }

    }

