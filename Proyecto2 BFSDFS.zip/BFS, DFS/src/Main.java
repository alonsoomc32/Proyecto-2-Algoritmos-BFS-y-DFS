/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Newools | Newemplates
 * and open the template in the editor.
 */
import grafo.G;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;
/**
 *
 * @author DiBot
 */
public class Main {
   
    public static void main(String[] args) {
       int num,dir,teo,auto;
       
        System.out.println("¿Cual modelo quieres?");
        System.out.println("1-Erdos & Renyi");
        System.out.println("2-Gilbert");
        System.out.println("3-Geografico Simple");
        System.out.println("4-Barabasi-Albert");
        System.out.println("5-Todos");
        Scanner t = new Scanner(System.in);
        teo = t.nextInt();
        System.out.println("¿Dirigido o no dirigido, 1,0?");
        Scanner v = new Scanner(System.in);
        dir = v.nextInt(); 
        System.out.println("Auto dirigido o no auto dirigido, 1,0?");
        Scanner a = new Scanner(System.in);
        auto = a.nextInt(); 
    
        switch (teo) {
        
            
 case 1:

        G Erdos30 = teorias.Erdos(30,35,dir,auto);
        manejo.guardaG("Erdos(30).gv",Erdos30,dir);
        manejo.guardaG("BreadthFirstSearchErdos(30).gv",Erdos30.BFS(Erdos30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(30).gv", Erdos30.DFS(Erdos30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(30).gv", Erdos30.DFSI(Erdos30.getEdge(0).tomarNodo1()),1);
        
        G Erdos100 = teorias.Erdos(100,80,dir,auto);
        manejo.guardaG("Erdos(100).gv",Erdos100,dir);
        manejo.guardaG("BreadthFirstSearchErdos(100).gv",Erdos100.BFS(Erdos100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(100).gv", Erdos100.DFS(Erdos100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(100).gv", Erdos100.DFSI(Erdos100.getEdge(0).tomarNodo1()),1);
       
        G Erdos500 = teorias.Erdos(500,300,dir,auto);
        manejo.guardaG("Erdos(500).gv",Erdos500,dir);
        manejo.guardaG("BreadthFirstSearchErdos(500).gv",Erdos500.BFS(Erdos500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(500).gv", Erdos500.DFS(Erdos500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(500).gv", Erdos500.DFSI(Erdos500.getEdge(0).tomarNodo1()),1);
 break;      
 case 2:
     
       G Gilbert30 = teorias.Gilbert(30,0.05,dir,auto);
       manejo.guardaG("Gilbert(30).gv",Gilbert30,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(30).gv",Gilbert30.BFS(Gilbert30.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(30).gv", Gilbert30.DFS(Gilbert30.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(30).gv", Gilbert30.DFSI(Gilbert30.getEdge(0).tomarNodo1()),1);
        
       G Gilbert100 = teorias.Gilbert(100,0.025,dir,auto);
       manejo.guardaG("Gilbert(100).gv",Gilbert100,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(100).gv",Gilbert100.BFS(Gilbert100.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(100).gv", Gilbert100.DFS(Gilbert100.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(100).gv", Gilbert100.DFSI(Gilbert100.getEdge(0).tomarNodo1()),1);
       
       G Gilbert500 = teorias.Gilbert(500,0.1,dir, auto);
       manejo.guardaG("Gilbert(500).gv",Gilbert500,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(500).gv",Gilbert500.BFS(Gilbert500.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(500).gv", Gilbert500.DFS(Gilbert500.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(500).gv", Gilbert500.DFSI(Gilbert500.getEdge(0).tomarNodo1()),1);
       System.out.print("ROSES ARE RED");
       
break;
case 3:
  
        G Geo30 = teorias.Geografico(30,0.1, dir, auto);
        manejo.guardaG("Geo(30).gv",Geo30,dir);
        manejo.guardaG("BreadthFirstSearchGeo(30).gv",Geo30.BFS(Geo30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(30).gv", Geo30.DFS(Geo30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(30).gv", Geo30.DFSI(Geo30.getEdge(0).tomarNodo1()),1);
      
        G Geo100 = teorias.Geografico(100,0.05,dir,auto);
        manejo.guardaG("Geo(100).gv",Geo100,dir);
        manejo.guardaG("BreadthFirstSearchGeo(100).gv",Geo100.BFS(Geo100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(100).gv", Geo100.DFS(Geo100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(100).gv", Geo100.DFSI(Geo100.getEdge(0).tomarNodo1()),1);
      
        G Geo500 = teorias.Geografico(500,0.035, dir, auto);
        manejo.guardaG("Geo(500).gv",Geo500,dir);
        manejo.guardaG("BreadthFirstSearchGeo(500).gv",Geo500.BFS(Geo500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(500).gv", Geo500.DFS(Geo500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(500).gv", Geo500.DFSI(Geo500.getEdge(0).tomarNodo1()),1);
         System.out.print("VIOLETS ARE BLUE");
        
       
break;
case 4:
        
        G Barabasi30 = teorias.Barabasi(30,10,dir, auto);
        manejo.guardaG("Barabasi(30).gv",Barabasi30,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(30).gv",Barabasi30.BFS(Barabasi30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(30).gv", Barabasi30.DFS(Barabasi30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(30).gv", Barabasi30.DFSI(Barabasi30.getEdge(0).tomarNodo1()),1);
        
       
        G Barabasi100 = teorias.Barabasi(100,25,dir,auto);
        manejo.guardaG("Barabasi(100).gv",Barabasi100,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(100).gv",Barabasi100.BFS(Barabasi100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(100).gv", Barabasi100.DFS(Barabasi100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(100).gv", Barabasi100.DFSI(Barabasi100.getEdge(0).tomarNodo1()),1);
      
        G Barabasi500 = teorias.Barabasi(500,50,dir, auto);
        manejo.guardaG("Barabasi(500).gv",Barabasi500,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(500).gv",Barabasi500.BFS(Barabasi500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(500).gv", Barabasi500.DFS(Barabasi500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(500).gv", Barabasi500.DFSI(Barabasi500.getEdge(0).tomarNodo1()),1);
      
break;
case 5:
        //Renyi&Erdos
        Erdos30 = teorias.Erdos(30,35,dir,auto);
        manejo.guardaG("Erdos(30).gv",Erdos30,dir);
        manejo.guardaG("BreadthFirstSearchErdos(30).gv",Erdos30.BFS(Erdos30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(30).gv", Erdos30.DFS(Erdos30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(30).gv", Erdos30.DFSI(Erdos30.getEdge(0).tomarNodo1()),1);
        
        Erdos100 = teorias.Erdos(100,80,dir,auto);
        manejo.guardaG("Erdos(100).gv",Erdos100,dir);
        manejo.guardaG("BreadthFirstSearchErdos(100).gv",Erdos100.BFS(Erdos100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(100).gv", Erdos100.DFS(Erdos100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(100).gv", Erdos100.DFSI(Erdos100.getEdge(0).tomarNodo1()),1);
       
        Erdos500 = teorias.Erdos(500,300,dir,auto);
        manejo.guardaG("Erdos(500).gv",Erdos500,dir);
        manejo.guardaG("BreadthFirstSearchErdos(500).gv",Erdos500.BFS(Erdos500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchErdos(500).gv", Erdos500.DFS(Erdos500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoErdos(500).gv", Erdos500.DFSI(Erdos500.getEdge(0).tomarNodo1()),1);
 ////////////////////////////////////////////////////////////////////////////
        //Gilbert
       Gilbert30 = teorias.Gilbert(30,0.05,dir,auto);
       manejo.guardaG("Gilbert(30).gv",Gilbert30,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(30).gv",Gilbert30.BFS(Gilbert30.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(30).gv", Gilbert30.DFS(Gilbert30.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(30).gv", Gilbert30.DFSI(Gilbert30.getEdge(0).tomarNodo1()),1);
        
       Gilbert100 = teorias.Gilbert(100,0.025,dir,auto);
       manejo.guardaG("Gilbert(100).gv",Gilbert100,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(100).gv",Gilbert100.BFS(Gilbert100.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(100).gv", Gilbert100.DFS(Gilbert100.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(100).gv", Gilbert100.DFSI(Gilbert100.getEdge(0).tomarNodo1()),1);
       
       Gilbert500 = teorias.Gilbert(500,0.1,dir, auto);
       manejo.guardaG("Gilbert(500).gv",Gilbert500,dir);
       manejo.guardaG("BreadthFirstSearchGilbert(500).gv",Gilbert500.BFS(Gilbert500.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchGilbert(500).gv", Gilbert500.DFS(Gilbert500.getEdge(0).tomarNodo1()),1);
       manejo.guardaG("DepthFirstSearchIterativoGilbert(500).gv", Gilbert500.DFSI(Gilbert500.getEdge(0).tomarNodo1()),1);
      
 ////////////////////////////////////////////////////////////////////////////
       //Geografico 
       Geo30 = teorias.Geografico(30,0.1, dir, auto);
        manejo.guardaG("Geo(30).gv",Geo30,dir);
        manejo.guardaG("BreadthFirstSearchGeo(30).gv",Geo30.BFS(Geo30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(30).gv", Geo30.DFS(Geo30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(30).gv", Geo30.DFSI(Geo30.getEdge(0).tomarNodo1()),1);
      
        Geo100 = teorias.Geografico(100,0.05,dir,auto);
        manejo.guardaG("Geo(100).gv",Geo100,dir);
        manejo.guardaG("BreadthFirstSearchGeo(100).gv",Geo100.BFS(Geo100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(100).gv", Geo100.DFS(Geo100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(100).gv", Geo100.DFSI(Geo100.getEdge(0).tomarNodo1()),1);
      
        Geo500 = teorias.Geografico(500,0.035, dir, auto);
        manejo.guardaG("Geo(500).gv",Geo500,dir);
        manejo.guardaG("BreadthFirstSearchGeo(500).gv",Geo500.BFS(Geo500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchGe0(500).gv", Geo500.DFS(Geo500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoGeo(500).gv", Geo500.DFSI(Geo500.getEdge(0).tomarNodo1()),1);
      

        
 ////////////////////////////////////////////////////////////////////////////
        //Barabasi Albert
        Barabasi30 = teorias.Barabasi(30,10,dir, auto);
        manejo.guardaG("Barabasi(30).gv",Barabasi30,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(30).gv",Barabasi30.BFS(Barabasi30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(30).gv", Barabasi30.DFS(Barabasi30.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(30).gv", Barabasi30.DFSI(Barabasi30.getEdge(0).tomarNodo1()),1);
        
       
        Barabasi100 = teorias.Barabasi(100,25,dir,auto);
        manejo.guardaG("Barabasi(100).gv",Barabasi100,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(100).gv",Barabasi100.BFS(Barabasi100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(100).gv", Barabasi100.DFS(Barabasi100.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(100).gv", Barabasi100.DFSI(Barabasi100.getEdge(0).tomarNodo1()),1);
      
        Barabasi500 = teorias.Barabasi(500,50,dir, auto);
        manejo.guardaG("Barabasi(500).gv",Barabasi500,dir);
        manejo.guardaG("BreadthFirstSearchBarabasi(500).gv",Barabasi500.BFS(Barabasi500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchBarabasi(500).gv", Barabasi500.DFS(Barabasi500.getEdge(0).tomarNodo1()),1);
        manejo.guardaG("DepthFirstSearchIterativoBarabasi(500).gv", Barabasi500.DFSI(Barabasi500.getEdge(0).tomarNodo1()),1);
       
 ////////////////////////////////////////////////////////////////////////////       
        
 break;

        
}
    }
}
